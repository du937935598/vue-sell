<template>
  <div class="about">
    seller 商家
  </div>
</template>

<script>
export default {}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
